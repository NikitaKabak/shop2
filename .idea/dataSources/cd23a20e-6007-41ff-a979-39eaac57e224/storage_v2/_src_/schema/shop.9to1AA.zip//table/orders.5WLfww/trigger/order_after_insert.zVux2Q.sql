create trigger order_AFTER_INSERT
  after INSERT
  on orders
  for each row
  BEGIN

END;

