create trigger order_BEFORE_INSERT
  before INSERT
  on orders
  for each row
  BEGIN

END;

